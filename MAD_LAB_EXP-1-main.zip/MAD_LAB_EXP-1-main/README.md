# MAD_LAB_EXP-1
Music Recommendation App

-Tapping on each music genre button will display a Snack-Bar indicating the selected genre.

-A Bottom Navigation Bar is added at the bottom, displaying a message.

-The Floating Action Button shows a Snack-Bar upon tapping, indicating the action taken.
